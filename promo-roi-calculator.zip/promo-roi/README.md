# Promo ROI Calculator — Deployment Guide

A self-contained Flask app that serves the Buy X Get 1 Free ROI calculator.
All logic runs in the browser — Flask is only needed to serve the HTML file.

---

## Option A · GitHub Pages (simplest — no Python needed)

1. Create a free GitHub account at github.com
2. Create a new repository called `promo-roi`
3. Upload ONLY the file `templates/index.html` — rename it to `index.html` at the root
4. Go to Settings → Pages → Source: Deploy from branch → main → / (root)
5. Save. In ~60 seconds your URL appears:
   `https://<your-username>.github.io/promo-roi`
6. Share that URL with your team. Done.

Best for: permanent shareable link, zero maintenance, completely free.
Limitation: URL is public (anyone with the link can access it).

---

## Option B · Render.com (recommended for team use)

Gives you a private, persistent URL on a real server. Free tier is fine.

### Step 1 — Push to GitHub

```bash
git init
git add .
git commit -m "promo roi calculator"
git branch -M main
git remote add origin https://github.com/<you>/promo-roi.git
git push -u origin main
```

### Step 2 — Deploy on Render

1. Go to https://render.com and sign up (free)
2. Click "New" → "Web Service"
3. Connect your GitHub repo
4. Render auto-detects `render.yaml` — just click **Deploy**
5. In ~2 minutes you get a URL like:
   `https://promo-roi-calculator.onrender.com`
6. Share that URL with your team

### Notes on Render free tier
- Spins down after 15 minutes of inactivity (first load after idle takes ~30s)
- Upgrade to $7/month Starter plan to keep it always-on
- No login/auth by default — anyone with the URL can use it

---

## Option C · Run locally on your machine (office LAN only)

```bash
# 1. Install dependencies (once)
pip install -r requirements.txt

# 2. Run the server
python app.py

# 3. Share with teammates on the same network
#    Your URL: http://<your-ip-address>:5000
#    Find your IP: ipconfig (Windows) or ifconfig (Mac/Linux)
```

This only works while your laptop is open and on the same WiFi/network.

---

## Adding password protection (optional)

If you want to restrict access, add HTTP Basic Auth to app.py:

```python
from flask import Flask, render_template, request, Response
import os

app = Flask(__name__)

USERNAME = os.environ.get("APP_USER", "hills")
PASSWORD = os.environ.get("APP_PASS", "promo2025")

def check_auth(username, password):
    return username == USERNAME and password == PASSWORD

def require_auth():
    return Response(
        "Login required", 401,
        {"WWW-Authenticate": 'Basic realm="Promo ROI"'}
    )

@app.before_request
def protect():
    auth = request.authorization
    if not auth or not check_auth(auth.username, auth.password):
        return require_auth()

@app.route("/")
def index():
    return render_template("index.html")
```

On Render, set `APP_USER` and `APP_PASS` as environment variables
in the dashboard (don't hardcode passwords in git).

---

## File structure

```
promo-roi/
├── app.py              ← Flask server (tiny — just serves the HTML)
├── requirements.txt    ← flask + gunicorn
├── render.yaml         ← Render.com auto-deploy config
├── README.md           ← this file
└── templates/
    └── index.html      ← the entire app (HTML + CSS + JS, self-contained)
```

All calculation logic lives in `templates/index.html`.
To update SKU data or rates, edit that file and redeploy (git push).
